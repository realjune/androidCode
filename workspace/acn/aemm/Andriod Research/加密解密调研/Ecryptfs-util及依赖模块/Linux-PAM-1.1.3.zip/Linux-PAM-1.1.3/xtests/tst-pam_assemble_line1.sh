#!/bin/bash

exec ./tst-pam_authfail tst-pam_assemble_line1
