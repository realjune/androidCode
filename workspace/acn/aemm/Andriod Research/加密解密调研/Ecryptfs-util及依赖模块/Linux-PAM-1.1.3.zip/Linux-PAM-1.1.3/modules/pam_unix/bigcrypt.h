extern char *bigcrypt(const char *key, const char *salt);
